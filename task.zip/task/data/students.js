// TODO 1: Buat data students
// code here
const students = [
    "Mark", "Chenle", "Doyoung"
]

// TODO 2: export data students
// code here
module.exports = students;